import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.Timer;

public class P4_Clark_Davin_MSConsole {
	Scanner in = new Scanner(System.in);
	private int size = 10;
	private int numBombs = 20;
	P4_Clark_Davin_MSModel m;
	BufferedImage[][] board;
	private boolean dead = false;
	int time = 0;

	P4_Clark_Davin_MSView v;
	BufferedImage[] nums = new BufferedImage[9];
	BufferedImage bomb, blank, flag, bombDeath, question, bombRevealed, bombWrong;

	P4_Clark_Davin_MSConsole() {
		m = new P4_Clark_Davin_MSModel(numBombs, size);
		v = new P4_Clark_Davin_MSView();
		board = new BufferedImage[size][size];
		for (int i = 0; i < nums.length; i++) {
			String source = "num_" + i + ".gif";
			try {
				nums[i] = ImageIO.read(new File(source));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			blank = ImageIO.read(new File("blank.gif"));
			flag = ImageIO.read(new File("bomb_flagged.gif"));
			bombDeath = ImageIO.read(new File("bomb_death.gif"));
			bombWrong = ImageIO.read(new File("bomb_wrong.gif"));
			bombRevealed = ImageIO.read(new File("bomb_revealed.gif"));
			question = ImageIO.read(new File("bomb_question.gif"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(board[0][0]);

		update();
		System.out.println(board[0][0]);

		v.drawBoard(board, size);
		v.getBoard().addMouseListener(new drawL());
		timer.start();
		m.flag(0,0);
		m.flag(0,0);
		update();
		v.mntmNewMenuItem.addActionListener(new restartL());
		v.mntmSetNumOf.addActionListener(new setBombL());
		v.mntmExit.addActionListener(new exitL());
		v.mntmHowToPlay.addActionListener(new helpL());
		v.mntmAbout.addActionListener(new aboutL());
	}
	public void show(int row, int col){
		m.show(row,col);
		update();
	}
	public void update() {
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				int[][] show = m.getShowArray();
				if(show[i][j]==0){
					board[i][j]= blank;
				}
				else if(show[i][j]==P4_Clark_Davin_MSModel.FLAG){
					board[i][j]= flag;
				}
				else {
					if(m.getBoard()[i][j]==P4_Clark_Davin_MSModel.BOMB){
						board[i][j]= bombDeath;
						dead = true;
					}
					else{
						board[i][j]= nums[m.getBoard()[i][j]];
					}
				}
				
			}
		}
	}
	//RUN BEFORE SHOWING ALL TILES
	public void deathUpdate(){
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				int[][] show = m.getShowArray();
				if(show[i][j]!=1){
					if(m.getBoard()[i][j]==P4_Clark_Davin_MSModel.BOMB){
						
						board[i][j]= bombRevealed;
						show[i][j]=1;
					}
				}
				if(show[i][j]==P4_Clark_Davin_MSModel.FLAG){
					board[i][j]= bombWrong;
				}
			}
		}
	}
	public void restart(){
		String message;
		if(dead){
			message="You DIED!!! Play Again?";
			
		}
		else
			message = "You WON!!! Play Again?";
		int answer = v.restartPopup(message);
		if(answer == JOptionPane.YES_OPTION){
			m = new P4_Clark_Davin_MSModel(numBombs,size);
			dead = false;
			update();
			time = 0;
			timer.start();
		}
		
	}
	Timer timer = new Timer(1000,new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			time++;
			v.timeText.setText(time+"");
			if(time == 1){
				v.drawBoard(board, size);
			}
		}
		
	});

	class drawL extends MouseAdapter {
		@Override
		public void mouseReleased(MouseEvent e) {
			if (!dead) {
				int col = e.getY() / (v.getBoardSize() / size);
				int row = e.getX() / (v.getBoardSize() / size);
				System.out.println(row + "," + col);
				if (e.getButton() == MouseEvent.BUTTON3) {
					m.flag(row, col);
					
					
					v.flagText.setText((m.getNumBombs()-m.getNumFlags())+"");
					update();
				} else {
					show(row, col);
				}
				v.drawBoard(board, size);
				if (m.clear() || dead) {
					deathUpdate();
					v.drawBoard(board, size);
					timer.stop();
					
					restart();
				}
				v.drawBoard(board, size);
			}
		}
		
	}
	class restartL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			m = new P4_Clark_Davin_MSModel(numBombs,size);
			dead = false;
			update();
			time = 0;
			timer.start();		
			v.drawBoard(board, size);
		}
		
	}
	class setBombL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			numBombs= Integer.parseInt(v.bombPopup());
			m = new P4_Clark_Davin_MSModel(numBombs,size);
			dead = false;
			update();
			time = 0;
			timer.start();		
			v.drawBoard(board, size);
		}
		
	}
	class exitL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			v.window.dispose();
			System.exit(0);
		}
		
	}
	class helpL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JEditorPane helpContent = null;
			try {
				helpContent = new JEditorPane(new URL("file:help.html"));
			} catch (MalformedURLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			JScrollPane helpPane = new JScrollPane(helpContent);
			helpPane.setPreferredSize(new Dimension(400,600));
			JOptionPane.showMessageDialog(null, helpPane, "How To Play", JOptionPane.PLAIN_MESSAGE, null);
		}
		
	}
	class aboutL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JEditorPane helpContent = null;
			try {
				helpContent = new JEditorPane(new URL("file:about.html"));
			} catch (MalformedURLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			JScrollPane helpPane = new JScrollPane(helpContent);
			helpPane.setPreferredSize(new Dimension(400,200));
			JOptionPane.showMessageDialog(null, helpPane, "About", JOptionPane.PLAIN_MESSAGE, null);
		}
		
	}
}
