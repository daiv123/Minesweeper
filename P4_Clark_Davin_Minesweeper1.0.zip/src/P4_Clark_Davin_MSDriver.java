/**
 * Davin Clark
 * P4
 * Mar 7, 2016
 * Time:30
 * 
 * This lab took a lot of time to do, and started to get very tedious. 
 */

public class P4_Clark_Davin_MSDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P4_Clark_Davin_MSConsole a = new P4_Clark_Davin_MSConsole();
	}

}
