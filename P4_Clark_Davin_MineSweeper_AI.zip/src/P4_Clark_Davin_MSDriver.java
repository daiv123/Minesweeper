/**
 * Davin Clark
 * P4
 * Mar 7, 2016
 * Time:30
 * 
 * This lab took a lot of time to do, and started to get very tedious. However, it was nice to 
 * see a finished product when I was done. For some reason, the constructor wasn't able to make
 * the panel display the board, so I did it in the timer, and it also gave it the appearance that
 * it takes one second to load the board. Other than that, the lab was really easy, but took a lot of time.
 */

public class P4_Clark_Davin_MSDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P4_Clark_Davin_MSConsole a = new P4_Clark_Davin_MSConsole();
	}

}
